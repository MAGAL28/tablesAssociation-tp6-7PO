package assoTable;
//SECK SERIGNE  ~ Simpara Ibrahim Kalilou
public class Zds1 {

	@SuppressWarnings("unused")
	public static int nbAleatoire() {
		return (int) (Math.random() * ((100000 - 1) + 1));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//************* *****      Test 1  CLASS ATList *******************
//				ATList test1 = new ATList();
//				test1.associe("Saliou", "457786547");
//				test1.associe("Badara", "765098234");
//				test1.associe("Mory", "453900765");
//				test1.associe("Maty", "109677543");
//				test1.associe("Samba", "239677!!!");
//				
//				System.out.println(test1);
//				

//				test1.supprime("Maty");
//				System.out.println(test1);

//				test1.supprime("Mory");
//				System.out.println(test1);
//				test1.supprime("Badara");
//				System.out.println(test1);
//				test1.supprime("Saliou");
//				System.out.println(test1);

		// Affichage et récuperation
		// Affichage et récuperation
//				String x3 = test1.get("Saliou");
//				System.out.println(x3);
//				String x0 = test1.get("Badara");
//				System.out.println(x0);	
//				String x1 = test1.get("Mory");
//				System.out.println(x1);
//				String x2 = test1.get("Maty");
//				System.out.println(x2);
//				String x31 = test1.get("Samba");
//				System.out.println(x31);

//***********  ********     Test 2 CLASS ATTree  ********************** 

		ATTree test2 = new ATTree();
		test2.associe("Boubacar", "44778");
//				test2.associe("Camille", "23778");
//				test2.associe("Caito", "54778");
//				test2.associe("Ahlem", "44778");
//				test2.associe("Abdou", "76778");
//				test2.associe("Charly", "34576");
//				test2.associe("Carime", "23576");
//				test2.associe("Badara", "76509");
//				test2.associe("Mory", "45390");
//				test2.associe("Maty", "10967");
//				test2.associe("Noura", "65778");
//				test2.associe("Aicha", "73254");
//				test2.associe("Absatou", "98254");
//				test2.associe("Abasse", "67890");
		//
//		System.out.println(test2.toString());
//		System.out.println();

//				System.out.println(test2.get("Saliou"));
//				System.out.println(test2.get("Maty"));
//				System.out.println(test2.get(""));

//				test2.supprime("Maty");
//				System.out.println(test2.toString());

//		       test2.supprime("Mory");
//		       System.out.println(test2.toString());
//		       test2.supprime("Camille");
//		       System.out.println(test2.toString());
//		       test2.supprime("Boubacar");
//		       System.out.println(test2.toString());

//			int  a = ATPerformance.nbAleatoire();
//				System.out.println(a);

//******************* MESURE DE PERFORMANCE ******************************

		ATList atl = new ATList();
		System.out.println("Mesure du temps de 100000 insertions pour ATList");
		@SuppressWarnings("unused")
		long start = 0;
		long end = 0;

		for (int k = 0; k < 100001; k = k + 1000) {
			int nbAle1 = nbAleatoire();
			int nbAlea2 = nbAleatoire();
			for (int i = 0; i <= k; i++) {
				start = start + System.nanoTime();
				atl.associe(String.valueOf(nbAle1), String.valueOf(nbAlea2));
				end = end + System.nanoTime();

			}
			System.out.println("Temps estimé pour " + k + " insertions  = " + ((end - start) / 100000) + " ms");

		}
		/*
		 * Mesure du temps de 100000 insertions pour ATList Temps estimé pour 1
		 * insertions = 4 ms Temps estimé pour 1000 insertions = 20 ms Temps estimé pour
		 * 10000 insertions = 192 ms Temps estimé pour 100000 insertions = 29539 ms
		 */

		ATList atl0 = new ATList();
		System.out.println("Mesure du temps Moyen pour 100000 insertions : ATList");
		@SuppressWarnings("unused")
		long start0 = 0;
		long end0 = 0;
		for (int k = 0; k < 100001; k += 1000) {
			int nbAle0 = nbAleatoire();
			for (int i = 0; i <= k; i++) {
				start0 = start0 + System.nanoTime();
				atl0.get(String.valueOf(nbAle0));
				end0 = end0 + System.nanoTime();
			}
			System.out.println("Temps estimé pour " + k + " insertions  = " + ((end0 - start0) / 100000) + " ms");

		}


		ATTree att = new ATTree();
		System.out.println("Mesure du temps de 100000 insertions pour ATTree");
		long debut = 0;
		long fin = 0;
		for (int k = 0; k < 2000001; k += 200000) {
			int nbAle1 = nbAleatoire();
			int nbAlea2 = nbAleatoire();
			for (int i = 0; i < k; i++) {
				debut = debut + System.nanoTime();
				att.associe(String.valueOf(nbAle1), String.valueOf(nbAlea2));
				fin = fin + System.nanoTime();

			}
			System.out.println("Temps estimé pour " + k + " insertions  = " + ((fin - debut) / 100000) + " ms");
		}

		ATTree att0 = new ATTree();
		System.out.println("Mesure du temps Moyen pour 100000 insertions : ATTree");
		long debut0 = 0;
		long fin0 = 0;
		for (int k = 0; k < 100001; k += 10000) {
			int nbAle1 = nbAleatoire();
			for (int i = 0; i < k; i++) {
				debut0 = debut0 + System.nanoTime();
				att0.get(String.valueOf(nbAle1));
				fin0 = fin0 + System.nanoTime();

			}
			System.out.println("Temps moyen estimé pour " + k + " insertions  = " + ((fin0 - debut0) / 100000) + " ms");
		}

	}

}
