package assoTable;
//SECK SERIGNE  ~ Simpara Ibrahim Kalilou
public class ATTree extends AssoTable {

	public class Noeud {
		public Paire x;
		public String valeur;
		public String cle;
		public Noeud filsG;
		public Noeud filsD;

		public Noeud(Paire x) {
			this.cle = x.cle;
			this.valeur = x.valeur;
			this.filsG = null;
			this.filsD = null;
		}

		public Noeud(Paire x, Noeud filsG, Noeud filsD) {
			this.cle = x.cle;
			this.valeur = x.valeur;
			this.filsD = filsD;
			this.filsG = filsG;
		}
	}

	public static final String ATPerformance = null;

	private Noeud racine;

	public ATTree() {
		racine = null;
	}

	@Override
	public void associe(String cle, String valeur) {
		racine = ajouteRec(racine, cle, valeur);
	}

	private Noeud ajouteRec(Noeud courant, String cle, String valeur) {
		if (courant != null) {
			if (courant.cle.equals(cle)) {
				courant.valeur = valeur;
			} else if (courant.cle.compareTo(cle) > 0) {
				courant.filsG = ajouteRec(courant.filsG, cle, valeur);
			} else if (courant.cle.compareTo(cle) < 0) {
				courant.filsD = ajouteRec(courant.filsD, cle, valeur);
			}
			return courant;
		} else {
			return new Noeud(new Paire(cle, valeur), null, null);
		}

	}

	@Override
	public void supprime(String cle) {
		racine = suprimeRec(racine, cle);
	}

	private Noeud suprimeRec(Noeud racine, String cle) {
		if (racine == null) {
			return racine;
		}
		if (cle.compareTo(racine.cle) < 0) {
			racine.filsG = suprimeRec(racine.filsG, cle);
		} else if (cle.compareTo(racine.cle) > 0) {
			racine.filsD = suprimeRec(racine.filsD, cle);
		} else {
			if (racine.filsG == null) {
				return racine.filsD;
			} else if (racine.filsD == null) {
				return racine.filsG;
			}
			racine.cle = mineValue(racine.filsD);
			racine.filsD = suprimeRec(racine.filsD, racine.cle);
		}
		return racine;

	}

	private String mineValue(Noeud racine) {
		String minv = racine.cle;
		while (racine.filsG != null) {
			minv = racine.filsG.cle;
			racine = racine.filsG;
		}
		return minv;

	}

	@Override
	public String get(String cle) {
		return getRec(cle, racine);
	}

	private String getRec(String cle, Noeud courant) {
		if (courant != null) {
			if (courant.cle.equals(cle)) {
				return courant.valeur;
			} else {
				if (courant.cle.compareTo(cle) > 0) {
					return getRec(cle, courant.filsG);
				} else if (courant.cle.compareTo(cle) < 0) {
					return getRec(cle, courant.filsD);
				}
			}
		}
		return "Empty root !";
	}

	public String toString() {
		return toStringRec(racine,"", "");
	}

	private String toStringRec(Noeud courant, String cle, String valeur) {
		String tmp = "";
		if (courant != null) {
			// Parcours infixe
			tmp += toStringRec(courant.filsG, cle, valeur + "    ");
			tmp += cle + valeur + courant.cle + " ~ " + courant.valeur + "\n";
			tmp += toStringRec(courant.filsD, cle, valeur + "   ");
		}
		return tmp;
	}

}
