package assoTable;
//SECK SERIGNE  ~ Simpara Ibrahim Kalilou
public class ATList extends AssoTable {

	private class Element {
		public Paire x;
		public Element suivant;

		public Element(Paire x, Element suivant) {
			this.x = x;
			this.suivant = suivant;
		}
	}

	private Element debut;

	public ATList() {
		this.debut = null;
	}

	public void associe(String cle, String valeur) {
		Paire a = new Paire(cle, valeur);
		Element courant = new Element(a, null);
		if (debut == null)
			debut = courant;
		else
			courant.suivant = debut;
		debut = courant;

	}

	public void supprime(String cle) {
		Element courant = debut;
		Element precedent = null;

		if (courant != null && courant.x.cle.equals(cle)) {
			debut = courant.suivant;
		}
		while (courant != null && !courant.x.cle.equals(cle)) {
			precedent = courant;
			courant = courant.suivant;
		}
		if (courant == null) {
			return;
		}
		precedent.suivant = courant.suivant;
	}

	public String get(String cle) {
		String res = "[ Assigned key value to ";
		Element courant = debut;
		while (courant != null) {
			if (courant.x.cle.equals(cle)) {
				return res + " " + cle + " " + " is : " + " " + courant.x.valeur + " ]";
			}
			courant = courant.suivant;
		}
		return null;
	}

	public String toString() {
		String res = " ";
		Element courant = debut;
		while (courant != null) {
			res += courant.x + " ";
			courant = courant.suivant;
		}
		return res;
	}

}